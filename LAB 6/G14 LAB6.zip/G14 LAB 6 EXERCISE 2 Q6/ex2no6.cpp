//Program 6.6
#include <iostream>
#include <fstream>
using namespace std;

struct catalog
{
	char title [50];
	char author[50];
	char publisher[30];
	int yearpublish;
	double price;
};

int main() {
	catalog book;
	
	
	fstream fbook("book.txt", ios::out|ios::binary); //open and write
	
	if (!fbook)
	{
		cout<<"Error opening file";
		return 0;
	}
	
	cout<<"These are the book information in the file:\n";
	string input;
	getline(fbook, input);
	cout << input<<endl;
	
	while(!fbook.eof())
	{
		//Display the recordabout the book
		cout<<"Title: "<<book.title<<endl;
		cout<<"Author: "<<book.author<<endl;
		cout<<"Publisher name: "<<book.publisher<<endl;
		cout<<"Year publish: "<<book.yearpublish<<endl;
		cout<<"Price: "<<book.price<<endl<<endl;
		
		//read the contents to the binary file
		for (int i=0; i<50 ; i++)
		{
			fbook.read(&book.title[i], sizeof(book.title[i]));	
		}
		for (int i=0; i<50 ; i++)
		{
			fbook.read(&book.author[i], sizeof(book.author[i]));
		}
		for (int i=0; i<50 ; i++)
		{
			fbook.read(&book.publisher[i], sizeof(book.publisher[i]));
		}
		fbook.read((char *)&book.yearpublish, sizeof(book.yearpublish));
		fbook.read((char *)&book.price, sizeof(book.price));


		
	}
	
	fbook.close();
	return 0;
	
}
