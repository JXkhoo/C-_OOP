#include <iostream>
#include <string>
using namespace std;
const int NUM_MONTH=12;
string nMonth[12]={"January","February","March","April","May,","June","July","August","September","October","November","December"};




class Month
{
	private:
		string name;
		int monthNumber;
		
	public:
		Month()
		{
			name="no name";
			monthNumber=0;
		}
		
		
		
		
		void setName(string a)
		{
			name=a;
		}
		void setmonthNumber(int mn)
		{
			monthNumber=mn;
		}
		
		string getMonthName() 
		{
			return name;
		}
		
		int getMonthNumber()
		{
			return monthNumber;
		}
		
		
		Month operator ++()
		{
			monthNumber++;
		}
		Month operator ++(int)
		{
			++monthNumber;
		}
		
	
		
		friend ostream &operator <<(ostream &output,Month &t);
		
		friend istream &operator >>(istream &input,Month &t);
		
		
		
			
};









ostream &operator <<(ostream &output,Month &t)
{
	output<<"Month: "<<t.name<<endl;
	output<<"Month number "<<t.monthNumber<<endl;
	return output;
}

istream &operator >>(istream &input,Month &t)
{
	input>>t.name>>t.monthNumber;
}


int main()
{
	int i;
	Month d[NUM_MONTH];
	Month t;
	
	
	
	
	
	
	
	
	for(i=0;i<12;i++)
	{	cout<<"enter all the month and number of month respectively"<<endl;
		cin>>d[i];
		cout<<d[i];
		 
		 
	}
	
	
	
	
	
	

	
	
	cout<<endl<<endl<<endl;
	cout<<"Enter the month that need to be post increment"<<endl;
	int r;
	cin>> r;
	
	cout<<d[r-1];
	
	cout<<"after increment";
	
	d[r-1]++;
	
	cout<<d[r-1];
	
	
	
	cout<<endl<<endl<<endl;
	cout<<"Enter the month that need to be pre increment"<<endl;
	int a;
	cin>> a;
	
	cout<<d[a-1];
	
	cout<<"after increment";
	
	d[a-1]++;
	
	cout<<d[a-1];
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 
	 
	 
	 
	 
	
	
	
	
	
	
	
	
	
	
	
}










