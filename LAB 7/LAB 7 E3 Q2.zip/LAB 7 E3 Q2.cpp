#include<iostream>
#include<fstream>
#include<iomanip>

using namespace std;

class Postgraduate
{
	private:
		string supervisor;
		string project;
	
	public:
		Postgraduate(string s,string p)
		{
			set(s,p);
		}
		
		void set(string s, string p)
		{
			this->supervisor=s;
			this->project=p;
		}
		
		void print()
		{
			cout<<supervisor<<setw(50)<<project;
		}
};

class Student
{
	private:
		string name;
		string academic;
		string program;
		Postgraduate *post;
		
	public:
		Student()
		{
			name="No entry";
			academic="No entry";
			program="No entry";
		}
		
		void set(string n,string a,string p1,Postgraduate *p)
		{
			name=n;
			academic=a;
			post=p;
			program=p1;
		}
		
		void print()
		{
			cout<<setw(50)<<name<<setw(50);
			post->print();
		}
};



int main()
{
	fstream input;
	input.open("student.txt",ios::in);
	
	int num;
	input>>num;
	
	Student s[num];
	Postgraduate *po;

	
	string name,program,aa,supervisor,project;
	input.ignore();	
	cout<<"The List of Postgraduate Students"<<endl;
	cout<<setw(5)<<"No"<<setw(50)<<"Name"<<setw(50)<<"Supervisor"<<setw(50)<<"Project"<<endl;
	
	int i=0;
	
	while(!input.eof())
	{
		input.ignore();
		getline(input,name);	
		getline(input,program);
		getline(input,aa);
		getline(input,supervisor);
		getline(input,project);
	
	
		po= new Postgraduate(supervisor,project);
		s[i].set(name,aa,program,po);
		i++;
	}
	
	for(int i=0;i<num;i++)
	{
	
		cout<<setw(5)<<i+1<<setw(50);
		s[i].print();
		cout<<endl;
	}
}
