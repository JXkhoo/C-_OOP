//PT2-SEC03  Assignment 1

//Group 14

// Khoo Jie Xuan
// Putera Syabil
//Pharveish Ail Selvam

#include "counter.h"
#include<iostream>
#include<cstdlib>
#include<iomanip>

void counter::getCount(int inCount)
	{
		count=inCount;
		cout<<"The initial value is "<<count<<endl;

	}

void counter::getMaxValue(int MaxVal)
	{
		maxValue=MaxVal; 
		cout<<"The maximum value is "<<maxValue<<endl;
	}


void counter::increment(const int count)
	{
			cout<<endl;
			cout<<"Increment(Add 1):"<<endl;
			if(count>=0 && count< maxValue)
			{
				newcount=count+1;
				cout<<newcount<<endl;
			}
			
			while(newcount<maxValue)
			{
				++newcount;
				cout<<newcount<<endl; 
			}
		

	}

void counter::decrement(const int count)
	{
		cout<<endl;
		cout<<"Decrement(Minus 1):"<<endl;
		if(count>0 && count< maxValue)
		{
			newcount=count-1;
			cout<<newcount<<endl;
		}
		
		while(newcount>0)
		{
			--newcount;
			cout<<newcount<<endl; 
		}
		
	}
	
int main()
{
	char action;
	int inCount,MaxVal;
	
	//Read user input
	cout<<"Enter the initial value : ";
	cin>>inCount;
	while(inCount<=0)
	{
		cout<<"Initial value must be bigger than zero. Reenter please"<<endl;
		cin>>inCount;	
	}

	
	//Set the initial value
	counter c1;
	c1.getCount(inCount);
	
	//Read the maximum value and set it
	cout<<"Enter the maximum value that it can be :";
	cin>>MaxVal;
	cout<<endl;
	while(inCount>=MaxVal)
	{
		cout<<"Maximum value have to be greater than initial value.Please enter again."<<endl;
		cout<<"Enter the maximum value that it can be :";
		cin>>MaxVal;
	}
	c1.getMaxValue(MaxVal);
	
	//Add or minus one from the initial value
	c1.increment(inCount);
	c1.decrement(inCount);
	
	
 }

