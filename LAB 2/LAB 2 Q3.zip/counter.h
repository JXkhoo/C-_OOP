//PT2-SEC03  Assignment 1

//Group 14

// Khoo Jie Xuan
// Putera Syabil
//Pharveish Ail Selvam

#ifndef COUNTER_H
#define COUNTER_H

using namespace std;

class counter 
{
     private :
          int count;
          int maxValue;
          
     public :
          void increment(const int);
          void decrement(const int);
          int setCount;
          int setMaxVal;
          void getCount(int);
          void getMaxValue(int);
          int newcount;
};

#endif
